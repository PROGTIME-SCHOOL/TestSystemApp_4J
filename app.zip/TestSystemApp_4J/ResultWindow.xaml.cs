﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TestSystemApp_4J.Models;

namespace TestSystemApp_4J
{
    /// <summary>
    /// Логика взаимодействия для ResultWindow.xaml
    /// </summary>
    public partial class ResultWindow : Window
    {
        public ResultWindow()
        {
            InitializeComponent();

            List<Result> results = new List<Result>()
            {
                new Result() { Id = 1, Scores = 1, StartDateTime = DateTime.Now, EndDateTime = DateTime.Now },
                new Result() { Id = 2, Scores = 1, StartDateTime = DateTime.Now, EndDateTime = DateTime.Now },
                new Result() { Id = 3, Scores = 1, StartDateTime = DateTime.Now, EndDateTime = DateTime.Now },
                new Result() { Id = 4, Scores = 1, StartDateTime = DateTime.Now, EndDateTime = DateTime.Now }
            };

            resultDataGrid.ItemsSource = results;
        }

        private void DataGrid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            // Получить выбранную строку
            //DataRowView selectedItem = (DataRowView)resultDataGrid.SelectedItem;

            var r = resultDataGrid.SelectedItem as Result;

            // Отобразить подсказку
            //MessageBox.Show(selectedItem.Row["Scores"].ToString());
        }
    }
}
